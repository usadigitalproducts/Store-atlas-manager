# **App Name**: Insight Capital

## Core Features:

- Revenue Tracking: Track total revenue from all sources.
- Profit Calculation: Calculate total profit after expenses.
- Margin Analysis: Calculate the profit margin as a percentage of revenue.
- Transaction Summary: Provide AI-generated summaries of financial performance.

## Style Guidelines:

- Primary color: Soft beige (#F5F5DC) for a neutral background that mimics the reference image.
- Accent color: Muted orange (#FFA07A) for the 'Generate Summary' button and key interactive elements, mirroring the warm tone from the reference.
- Font: 'PT Sans' for body and headers to offer clean readability
- Card-based layout with soft, rounded corners for a modern, approachable design, matching the visual structure of the image.
- Use simple, outline icons to represent different financial metrics, maintaining consistency with the image's minimalist style.